$(function() {
	
	$('ul').before('<p> Just Updated </p>');
	
	$('li.hot').prepend('+ '); 
	
	$('ul').after('<li>Gluten-free soy sauce</li>');
	
	

});