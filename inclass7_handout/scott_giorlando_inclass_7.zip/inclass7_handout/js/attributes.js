$(function() {
	$('li#three').removeClass('hot');
	$('li.hot').addClass('favorite');
});